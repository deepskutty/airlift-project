from flask import Flask, request, current_app, jsonify, make_response
import json
from functools import update_wrapper
from datetime import timedelta
from flask_cors import CORS


app = Flask(__name__)
CORS(app)

@app.route('/login', methods=['POST'])
def login_user():

	data = '[{"name": "Deepa","user_name": "deepa","email": "deeparanigopi98@gmail.com","password": "Deepa@22","status": "in-active"},{"name": "Ganesh","user_name": "ganesh","email": "ganesh@gmail.com","password": "Ganesh@11","status": "in-active"},{"name": "Ramya","user_name": "ramya","email": "ramya@gmail.com","password": "Ramya@11","status": "active"}]'

	x = json.loads(data)
	request_data = request.get_json()
	print(type(request_data))
	for y in x:
		if y['user_name']==request_data['user_name'] or y['email']==request_data['user_name']:
			if y['password']==request_data['password']:
				if y['status']=="active":
					return jsonify({'message' : "correct"})
				else:
					return jsonify({'message' : "Your account is In-active"})
			else:
				return jsonify({'message' : "Please check your Password"})
		else:
			return jsonify({'message' : "Please check your username or email"})

	return jsonify({'message' : "no"})


if  __name__ == '__main__':
    app.run(debug=True)

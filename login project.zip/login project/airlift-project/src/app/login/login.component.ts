import { Component, OnInit, Injectable } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  private REST_API_SERVER = "http://localhost:5000/login";
  credential = new FormGroup({
    user_name: new FormControl('', Validators.required),
    password: new FormControl('', Validators.required),
  });
  fillEmailandPassword = false;
  clickForgetPassword = false;
  errorMessage = "";

  constructor(private httpClient: HttpClient, private routingNavigate: Router,) { }

  ngOnInit(): void {
  }

  login() {
  //  Client
    // if (this.credential.valid) {
    //   let userListData = [
    //     { "name": "Deepa", "user_name": "deepa", "email": "deeparanigopi98@gmail.com", "password": "Deepa@22", "status": "active" },
    //     { "name": "Ganesh", "user_name": "ganesh", "email": "ganesh@gmail.com", "password": "Ganesh@11", "status": "in-active" },
    //     { "name": "Ramya", "user_name": "ramya", "email": "ramya@gmail.com", "password": "Ramya@11", "status": "active" }
    //   ];
    //   for(let i=0; i<userListData.length; i++) {
    //     if(this.credential.value.user_name==userListData[i].user_name || this.credential.value.user_name==userListData[i].email){
    //       if(this.credential.value.password==userListData[i].password){
    //         if(userListData[i].status=='active'){
    //           this.routingNavigate.navigate(['/next-page']);
    //           break;
    //         }else{
    //           this.errorMessage="Your account is In-active";
    //           break;
    //         }
    //       }else{
    //         this.errorMessage="Please check your Password";
    //         break;
    //       }
    //     }else{
    //       this.errorMessage="Please check your username or email";
    //       break;
    //     }
    //   }
    // }

    // Server hit
    if (this.credential.valid) {
      const headers = new HttpHeaders().set('Content-Type', 'application/json;');
      this.httpClient.post(this.REST_API_SERVER, this.credential.value, { headers: headers }).subscribe((data: any) => {
        if (data.message === 'correct') {
          this.routingNavigate.navigate(['/next-page']);
        } else {
          this.errorMessage = data.message;
        }
      });
    }
  }

}
